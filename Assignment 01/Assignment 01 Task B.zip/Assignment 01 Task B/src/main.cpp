/*
  ------------------------------------------------------
  TASK B: Button Press Type Detection (Short / Long Press)
  Name: Sabika Batool Zaidi
  Reg. No: 23-NTU-CS-1282
  ------------------------------------------------------
  Hardware:
    - Blue LED:  D2
    - Red LED:   D4
    - Green LED: D5
    - Button 1:  D35  (Short/Long press)
    - Button 2:  D32  (Reset)
    - Buzzer:    D25
    - OLED: SDA=D21, SCL=D22
  ------------------------------------------------------
  Short press  → Toggle LEDs ON/OFF
  Long press (>1.5 sec) → Play buzzer tone
  Button 2 → Reset (All OFF)
*/

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// Pin definitions
#define BLUE_LED 2
#define RED_LED 4
#define GREEN_LED 5
#define BUTTON1 35
#define BUTTON2 32
#define BUZZER 25

// Variables
bool ledsOn = false;
unsigned long pressTime = 0;
unsigned long releaseTime = 0;
bool buttonState = false;
bool lastButtonState = false;

void setup() {
  // LED and Buzzer setup
  pinMode(BLUE_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(BUZZER, OUTPUT);

  // Buttons
  pinMode(BUTTON1, INPUT);
  pinMode(BUTTON2, INPUT);

  // OLED setup
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.print("Task B: Start");
  display.display();
  delay(1000);
}

void loop() {
  buttonState = digitalRead(BUTTON1);

  // Detect button press
  if (buttonState == HIGH && lastButtonState == LOW) {
    pressTime = millis();
  }

  // Detect button release
  if (buttonState == LOW && lastButtonState == HIGH) {
    releaseTime = millis();
    unsigned long duration = releaseTime - pressTime;

    display.clearDisplay();
    display.setCursor(0, 0);

    if (duration < 1500) {
      // Short press → Toggle LEDs
      ledsOn = !ledsOn;
      digitalWrite(BLUE_LED, ledsOn);
      digitalWrite(RED_LED, ledsOn);
      digitalWrite(GREEN_LED, ledsOn);

      display.print("Short Press:");
      display.setCursor(0, 15);
      if (ledsOn) display.print("LEDs ON");
      else display.print("LEDs OFF");
    } 
    else {
      // Long press → Buzzer
      display.print("Long Press:");
      display.setCursor(0, 15);
      display.print("Buzzer Sound");
      tone(BUZZER, 1000, 600);  // 1000 Hz for 0.6 sec
    }

    display.display();
  }

  // Reset button → turn everything off
  if (digitalRead(BUTTON2) == HIGH) {
    ledsOn = false;
    digitalWrite(BLUE_LED, LOW);
    digitalWrite(RED_LED, LOW);
    digitalWrite(GREEN_LED, LOW);
    noTone(BUZZER);

    display.clearDisplay();
    display.setCursor(0, 0);
    display.print("System Reset");
    display.display();
    delay(500);
  }

  lastButtonState = buttonState;
}