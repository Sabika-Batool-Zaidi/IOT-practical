/*
  ---------------------------------------------------------------
  TASK A - LED Mode Control with OLED Display (ESP32)

  Name: Sabika Batool Zaidi
  Registration No: 23-NTU-CS-1282
  ---------------------------------------------------------------
  Description:
  This program controls three LEDs connected to the ESP32 board.
  Two buttons are used to switch between LED modes and reset them.
  The current mode is displayed on an SSD1306 OLED display.

  Components and Pin Connections:
  ---------------------------------------------------------------
  Blue LED   → D2
  Red LED    → D4
  Green LED  → D5
  Button 1   → D35 (Mode Cycle)
  Button 2   → D32 (Reset)
  Buzzer     → D25
  OLED SDA   → D21
  OLED SCL   → D22
  OLED VCC   → 3V3
  OLED GND   → GND
  ---------------------------------------------------------------
*/

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// ------------------- Pin Definitions -------------------
#define LED_BLUE   2
#define LED_RED    4
#define LED_GREEN  5
#define BTN1       35
#define BTN2       32
#define BUZZER     25

// ------------------- Global Variables -------------------
int mode = 0;
const int totalModes = 4;

// ------------------- Function Declarations --------------
void showMode();
void allOff();
void alternateBlink();
void bothOn();
void pwmFade();

// ------------------- Setup Function ---------------------
void setup() {
  pinMode(LED_BLUE, OUTPUT);
  pinMode(LED_RED, OUTPUT);
  pinMode(LED_GREEN, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  pinMode(BTN1, INPUT_PULLUP);
  pinMode(BTN2, INPUT_PULLUP);
  
  Wire.begin(21, 22);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    while (true);
  }

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(0, 10);
  display.println("Mode 0: All OFF");
  display.display();
}

// ------------------- Main Loop --------------------------
void loop() {
  static bool lastBtn1 = HIGH;
  static bool lastBtn2 = HIGH;

  bool btn1 = digitalRead(BTN1);
  bool btn2 = digitalRead(BTN2);

  // Button 1 → Cycle through LED modes
  if (lastBtn1 == HIGH && btn1 == LOW) {
    mode = (mode + 1) % totalModes;
    showMode();
  }

  // Button 2 → Reset to Mode 0
  if (lastBtn2 == HIGH && btn2 == LOW) {
    mode = 0;
    showMode();
  }

  lastBtn1 = btn1;
  lastBtn2 = btn2;

  switch (mode) {
    case 0: allOff(); break;
    case 1: alternateBlink(); break;
    case 2: bothOn(); break;
    case 3: pwmFade(); break;
  }
}

// ------------------- OLED Display Function ---------------
void showMode() {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(0, 10);
  display.print("Mode ");
  display.println(mode);
  display.display();
}

// ------------------- Mode Functions ----------------------
void allOff() {
  digitalWrite(LED_BLUE, LOW);
  digitalWrite(LED_RED, LOW);
  digitalWrite(LED_GREEN, LOW);
}

void alternateBlink() {
  digitalWrite(LED_BLUE, HIGH);
  digitalWrite(LED_RED, LOW);
  delay(300);
  digitalWrite(LED_BLUE, LOW);
  digitalWrite(LED_RED, HIGH);
  delay(300);
}

void bothOn() {
  digitalWrite(LED_BLUE, HIGH);
  digitalWrite(LED_RED, HIGH);
  digitalWrite(LED_GREEN, LOW);
}

void pwmFade() {
  digitalWrite(LED_BLUE, LOW);
  digitalWrite(LED_RED, LOW);
  for (int i = 0; i <= 255; i++) {
    analogWrite(LED_GREEN, i);
    delay(5);
  }
  for (int i = 255; i >= 0; i--) {
    analogWrite(LED_GREEN, i);
    delay(5);
  }
}