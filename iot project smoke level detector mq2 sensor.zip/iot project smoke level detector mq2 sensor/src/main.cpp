#include <Arduino.h>
#include <WiFi.h>

/************ BLYNK CONFIG ************/
#define BLYNK_PRINT Serial
#define BLYNK_TEMPLATE_ID "TMPL6Qn-korQc"
#define BLYNK_TEMPLATE_NAME "smoke gas detector"
#define BLYNK_AUTH_TOKEN "MxA1hq2ju3z0V5hHu1fpJdn5swegF-ko"

#include <BlynkSimpleEsp32.h>

/************ LIBRARIES ************/
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <DHT.h>

/************ WIFI CONFIG ************/
char ssid[] = "Sweet Home.";
char pass[] = "turab10911901";

/************ PIN CONFIG ************/
#define MQ2_PIN     34
#define BUZZER_PIN  26
#define LED_PIN     25

#define DHT_PIN     27
#define DHT_TYPE    DHT11   // Change to DHT22 if required

/************ OLED CONFIG ************/
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET   -1
#define OLED_ADDR    0x3C

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

/************ OBJECTS ************/
DHT dht(DHT_PIN, DHT_TYPE);
BlynkTimer timer;

/************ VARIABLES ************/
int gasThreshold = 1400;
int baseline = 0;

bool ledState = false;
bool buzzerState = false;

float currentTemp = 0.0;
float currentHumidity = 0.0;

/************ BASELINE CALIBRATION ************/
void calibrateBaseline() {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);
  display.setCursor(0, 0);
  display.println("Calibrating MQ2...");
  display.display();

  long sum = 0;
  const int samples = 50;

  for (int i = 0; i < samples; i++) {
    sum += analogRead(MQ2_PIN);
    delay(100);
  }

  baseline = sum / samples;

  display.clearDisplay();
  display.println("Calibration Done");
  display.display();
  delay(1000);
}

/************ READ MQ2 SENSOR ************/
void readMQ2() {
  int rawValue = analogRead(MQ2_PIN);
  int gasValue = rawValue - baseline;
  if (gasValue < 0) gasValue = 0;

  bool danger = gasValue > gasThreshold;

  if (danger) {
    digitalWrite(LED_PIN, HIGH);
    digitalWrite(BUZZER_PIN, HIGH);
    ledState = true;
    buzzerState = true;
    Blynk.logEvent("smoke_alert", "Smoke/Gas Detected!");
  } else {
    digitalWrite(LED_PIN, LOW);
    digitalWrite(BUZZER_PIN, LOW);
    ledState = false;
    buzzerState = false;
  }

  // Send data to Blynk
  Blynk.virtualWrite(V0, gasValue);
  Blynk.virtualWrite(V3, gasValue);
  Blynk.virtualWrite(V1, ledState);
  Blynk.virtualWrite(V2, buzzerState);

  // OLED DISPLAY
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);

  display.setCursor(0, 0);
  display.println("Smoke & Gas Monitor");

  display.setCursor(0, 16);
  display.print("Gas: ");
  display.println(gasValue);

  display.setCursor(0, 28);
  display.print("Temp: ");
  display.print(currentTemp);
  display.println(" C");

  display.setCursor(0, 40);
  display.print("Hum: ");
  display.print(currentHumidity);
  display.println(" %");

  display.setCursor(0, 52);
  display.print("Status: ");
  display.println(danger ? "DANGER" : "SAFE");

  display.display();
}

/************ READ DHT SENSOR ************/
void readDHT() {
  float h = dht.readHumidity();
  float t = dht.readTemperature();

  if (isnan(h) || isnan(t)) {
    Serial.println("DHT read failed");
    return;
  }

  currentTemp = t;
  currentHumidity = h;

  Blynk.virtualWrite(V4, currentTemp);
  Blynk.virtualWrite(V5, currentHumidity);

  Serial.print("Temp: ");
  Serial.print(currentTemp);
  Serial.print(" C | Humidity: ");
  Serial.print(currentHumidity);
  Serial.println(" %");
}

/************ BLYNK CONTROLS ************/
BLYNK_WRITE(V1) {
  ledState = param.asInt();
  digitalWrite(LED_PIN, ledState);
}

BLYNK_WRITE(V2) {
  buzzerState = param.asInt();
  digitalWrite(BUZZER_PIN, buzzerState);
}

/************ SETUP ************/
void setup() {
  Serial.begin(9600);

  pinMode(MQ2_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  Wire.begin(21, 22);
  if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    while (true);
  }

  display.clearDisplay();
  display.println("System Starting...");
  display.display();

  dht.begin();
  calibrateBaseline();

  Blynk.begin(BLYNK_AUTH_TOKEN, ssid, pass);

  timer.setInterval(1000L, readMQ2);
  timer.setInterval(2000L, readDHT);
}

/************ LOOP ************/
void loop() {
  Blynk.run();
  timer.run();
}
